# 导入所需的库
import re
from bs4 import BeautifulSoup
import pandas as pd
from selenium import webdriver
import time
from selenium.webdriver.edge.options import Options

# 定义用户代理字符串
user_ag = [
    'MQQBrowser/26 Mozilla/5.0 (Linux; U; Android 2.3.7; zh-cn; MB200 Build/GRJ22; ' + 'CyanogenMod-7) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) " + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36"]

user_ag2 = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3493.3 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"]

# 设置浏览器选项
options = Options()
options.add_argument('user-agent=%s' % user_ag[0])
options.add_argument("--headless")
options.add_argument("--disable-infobars")
options.add_argument('blink-settings=imagesEnabled=false')
# 使用配置的选项初始化 Edge WebDriver 实例
driver = webdriver.Edge(options=options)

url = "https://www.monreseau-it.fr/liste-revendeurs-it.htm#page=1&mshact=48,49,50,51,52,53,54,55,56,57,58,59,60,61"

path = "C:\\Users\\MAO\\Desktop\\Nouveau dossier\\"
fichier_name = 'fichiername1-150.csv'

# 获取最大页数
driver.get(url)
time.sleep(5)
html = driver.page_source
soup = BeautifulSoup(html, 'html.parser')
driver.quit()
nb_societe = soup.find("span", {"class": "blue"}).text
nb_societe = int(nb_societe.replace("sociétés", "").replace(" ", ""))
nb_page = int(nb_societe / 25 + 0.99)
print("nb_page:", nb_page)

# 爬取每页数据
for page in range(1, 151):

    list_compag_url = []
    list_compag_siren = []
    list_compag_name = []
    list_type = []
    list_nb_Effectif = []
    list_nb_CF = []
    list_grossistes_list = []

    # 修改用户代理
    options.add_argument('user-agent=%s' % user_ag[page % 2])
    # 初始化 Edge WebDriver 实例 更改用户代理
    driver = webdriver.Edge(options=options)
    print("page:", page)
    # 构建 URL
    url = "https://www.monreseau-it.fr/liste-revendeurs-it.htm#page=" + str(
        page) + "&mshact=48,49,50,51,52,53,54,55,56,57,58,59,60,61"

    # 加载 URL
    driver.get(url)
    time.sleep(5)
    html = driver.page_source
    soup = BeautifulSoup(html, 'html.parser')
    # 关闭 WebDriver 实例
    driver.quit()

    # 提取公司名称
    list_compag = soup.find_all("a", href=re.compile("revendeur/"))
    list_compag_url = list(list_compag)
    list_compag_name = list_compag_name + [str(list_compag[i].text) for i in range(len(list_compag))]

    # 计数
    count = 0
    for compag_url in list_compag_url:
        # 增加计数
        count += 1
        print("count:", count)
        # 将compag_url转换为字符串
        compag_url = str(compag_url)

        # 提取href链接的起始和结束索引
        beg_href_compag_url = compag_url.index('href="') + 6
        end_href_compag_url = compag_url.rindex('.htm') + 4
        # 构建完整的href链接
        href = "https://www.monreseau-it.fr/" + compag_url[beg_href_compag_url: end_href_compag_url]
        print(href)
        # 提取SIREN号并添加到list_compag_siren列表中
        list_compag_siren.append(href[-13:-4])
        # 使用不同的用户代理
        options.add_argument('user-agent=%s' % user_ag2[count % 2])
        # 初始化 Edge WebDriver 实例 更改用户代理
        driver = webdriver.Edge(options=options)
        # 加载公司URL
        driver.get(href)
        html = driver.page_source
        soup = BeautifulSoup(html, 'html.parser')
        driver.quit()

        # 获取公司类型数据
        type = str(soup.find("div", class_="span9").h2)[4:-5]
        # 获取关键数字数据
        chiffre_cle = soup.find("table", class_="table table-bordered")
        if "<td>" in str(chiffre_cle):
            chiffre_cle = chiffre_cle.find_all("td")
            nb_Effectif = str(chiffre_cle[0])[4:-13]
            if len(chiffre_cle) == 2:
                nb_CF = str(chiffre_cle[1])[4:-5]
            else:
                nb_CF = " "
        else:
            nb_Effectif = " "
            nb_CF = " "
        # 获取批发商数据
        grossistes = soup.find("div", id="grossistes")
        if "li" in str(grossistes):
            grossistes = grossistes.find_all("li")
            grossistes_list = [str(grossiste)[str(grossiste).index('">') + 2:-9] for grossiste in grossistes]
        else:
            grossistes_list = " "

        print(type, nb_Effectif, nb_CF, grossistes_list)
        # 将数据添加到列表中
        list_type.append(type)
        list_nb_Effectif.append(nb_Effectif)
        list_nb_CF.append(nb_CF)
        list_grossistes_list.append(grossistes_list)

    print(list_compag_name, list_compag_siren)
    # 创建另一个DataFrame对象并将其保存到CSV文件中
    df = pd.DataFrame({'nom entreprise': list_compag_name, "siren": list_compag_siren, 'type': list_type,
                       'nb Effectif': list_nb_Effectif, "Chiffre d'Affaire": list_nb_CF,
                       "Grossiste": list_grossistes_list})

    df.to_csv(path + fichier_name, mode='a', header=False, index=False)

